package com.example.booktrackr;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.albumtrackr.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {

    // creating a variable for array list and context.
    private final BookList BookArrayList;
    private final Context context;
    private final String SERVICE_URI = "https://booktrackrapi.azurewebsites.net/api/BookList/";

    private final ArrayList<BookList> lists = new ArrayList<BookList>();

    // creating a constructor for our variables.
    public BookAdapter(BookList bookArrayList, Context context) {
        this.BookArrayList = bookArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public BookAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // below line is to inflate our layout.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_book, parent, false);
        return new ViewHolder(view);

    }


    @Override
    public void onBindViewHolder(@NonNull BookAdapter.ViewHolder holder, int position) {
        // setting data to our views of recycler view.
        Book modal = BookArrayList.getBooks().get(holder.getAdapterPosition());
        holder.BookName.setText(modal.getName());
        holder.BookName.setText(modal.getAuthor());

        // Getting the position of the item (the book) then getting the ID in the API request below
        Book bookToDelete = BookArrayList.getBooks().get(holder.getAdapterPosition());
        // List ID
        Integer listID = BookArrayList.getId();

        if (BookArrayList.getUsername().equals(getUserId())) {
            holder.bookDelete.setVisibility(View.VISIBLE);
        } else {
            holder.bookDelete.setVisibility(View.INVISIBLE);
        }

        holder.bookDelete.setOnClickListener(v -> {
            RequestQueue queue = Volley.newRequestQueue(context);
            StringRequest stringRequest = new StringRequest(Request.Method.DELETE, SERVICE_URI + listID.toString() + "/book/" + bookToDelete.getId().toString(),
                    response -> {

                        List<Book> books = BookArrayList.getAlbums();
                        BookArrayList.setBooks(books);

                        books.remove(bookToDelete);

                        // Internationalised - Book deleted
                        Toast.makeText(context, context.getResources().getString(R.string.Book_delete), Toast.LENGTH_LONG).show();

                        notifyDataSetChanged();
                    }, error -> {
                parseVolleyError(error);

                // Internationalised - Book delete failure
                Toast.makeText(context, context.getResources().getString(R.string.book_delete_fail), Toast.LENGTH_SHORT).show();
            });

            queue.add(stringRequest);

        });
    }


    public void parseVolleyError(VolleyError error) {
        try {
            String responseBody = new String(error.networkResponse.data, StandardCharsets.UTF_8);
            JSONObject data = new JSONObject(responseBody);
            JSONArray errors = data.getJSONArray("errors");
            JSONObject jsonMessage = errors.getJSONObject(0);
            String message = jsonMessage.getString("message");
            Toast.makeText(context, message, Toast.LENGTH_LONG).show();
        } catch (JSONException e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public int getItemCount() {
        // returning the size of array list.
        return BookArrayList.getAlbums().size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our views.
        private final TextView BookName;
        private final TextView AuthorName;
        final Button bookDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // initializing our views with their ids.
            BookName = itemView.findViewById(R.id.BookName);
            AuthorName = itemView.findViewById(R.id.AuthorName);
            bookDelete = itemView.findViewById(R.id.button_deleteBook);


        }
    }

    public String getUserId() {
        return Build.BOARD.length() % 10 + Build.BRAND.length() % 10 + Build.DEVICE.length() % 10 + Build.DISPLAY.length() % 10 + Build.HOST.length() % 10 + Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10 + Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10 + Build.TAGS.length() % 10 + Build.TYPE + Build.USER.length() % 10;
    }
}