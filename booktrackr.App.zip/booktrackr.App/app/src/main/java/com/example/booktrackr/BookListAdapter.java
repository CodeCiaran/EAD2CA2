package com.example.booktrackr;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookListAdapter extends RecyclerView.Adapter<BookListAdapter.ViewHolder> {

    // creating a variable for array list and context.
    private final ArrayList<BookList> BookArrayList;

    // creating a constructor for our variables.
    public BookListAdapter(ArrayList<BookList> bookArrayList, Context context) {
        this.BookArrayList = BookArrayList;
    }

    @NonNull
    @Override
    public BookListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // below line is to inflate our layout.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_albumlist, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookListAdapter.ViewHolder holder, int position) {
        // setting data to our views of recycler view.
        BookList modal = BookArrayList.get(position);
        holder.BListName.setText(modal.getName());
    }

    @Override
    public int getItemCount() {
        // returning the size of array list.
        return BookArrayList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our views.
        private final TextView BListName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // initializing our views with their ids.
            BListName = itemView.findViewById(R.id.aListName);

            TextView BListName2 = itemView.findViewById(R.id.textView_bookListName);
        }
    }


}