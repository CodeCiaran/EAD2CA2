package com.example.booktrackr;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class SecondaryActivity extends AppCompatActivity implements AddBookDialog.DialogListenerAddBook {
    Integer id;
    Integer bookId;

    private BookAdapter adapter;
    private RecyclerView book;
    private BookList bookList;
    private final ArrayList<BookList> lists = new ArrayList<BookList>();
    private final String SERVICE_URI = "https://booktrackrapi.azurewebsites.net/api/BookList/";
    private ProgressBar progressBar;
    private String UserId = "";

    private TextView bookListName;

    Button bookdelete;
    Button secondaryDelete;
    FloatingActionButton addBook;


    ConstraintLayout layout1;
    LinearLayout layout2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);
        Intent intent = getIntent();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);


        id = intent.getIntExtra("bookListID", 0);
        bookId = intent.getIntExtra("bookID", 0);

        layout1 = findViewById(R.id.secondary_layout);
        layout2 = findViewById(R.id.linearLayout3);

        book = findViewById(R.id.idBooks);
        progressBar = findViewById(R.id.progressBar);

        secondaryDelete = (Button) findViewById(R.id.button_delete2);
        bookdelete = (Button) findViewById(R.id.button_deleteBook);
        addBook = (FloatingActionButton) findViewById(R.id.fab_add);


        getData();
        delete();
        addBook();

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void getData() {
        // creating a new variable for our request queue
        RequestQueue queue = Volley.newRequestQueue(SecondaryActivity.this);
        // in this case the data we are getting is in the form
        // of array so we are making a json array request.
        // below is the line where we are making an json array
        // request and then extracting data from each json object.

        UserId = getUserId();
        JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Request.Method.GET, SERVICE_URI + id.toString(), null, response -> {
            progressBar.setVisibility(View.GONE);
            book.setVisibility(View.VISIBLE);
            // creating a new json object and
            // getting each object from our json array.
            try {
                // we are getting each json object.
                JSONArray jsonArray = new JSONArray();
                ArrayList<Book> bookArrayList = new ArrayList<Book>();

                Log.e("toString() error: ", response.toString());
                String listid = response.getString("id");
                String username = response.getString("username");
                String name = response.getString("name");


                if (response.optJSONArray("albums") != null) {
                    jsonArray = response.optJSONArray("albums");
                }


                if (jsonArray != null) {
                    for (int j = 0; j < jsonArray.length(); j++) {
                        JSONObject obj = jsonArray.getJSONObject(j);
                        String id = obj.getString("id");
                        String bookName = obj.getString("name");
                        String authorName = obj.getString("author");

                        bookArrayList.add(new Book(Integer.parseInt(id), authorName, bookName));
                    }
                }


                bookList = new BookList(Integer.parseInt(listid), username, name,bookArrayList);

                buildRecyclerView();


            } catch (JSONException e) {
                e.printStackTrace();
            }
            // Internationalised - Failure to retrieve data
        }, error -> Toast.makeText(SecondaryActivity.this, getResources().getString(R.string.fail_get_data), Toast.LENGTH_SHORT).show());
        queue.add(jsonArrayRequest);
    }

    private void buildRecyclerView() {


        // initializing our adapter class.
        adapter = new BookAdapter(bookList, SecondaryActivity.this);

        // adding layout manager
        // to our recycler view.
        LinearLayoutManager manager = new LinearLayoutManager(this);
        book.setHasFixedSize(true);

        // setting layout manager
        // to our recycler view.
        book.setLayoutManager(manager);

        // globally
        bookListName = (TextView) findViewById(R.id.textView_bookListName);


        //in your OnCreate() method
        bookListName.setText(bookList.getName());

        bookListName.setVisibility(View.VISIBLE);



        // setting adapter to
        // our recycler view.
        book.setAdapter(adapter);

        if (bookList.getUsername().equals(UserId)) { //checking if user can modify list
            secondaryDelete.setVisibility(View.VISIBLE);
            addBook.setVisibility(View.VISIBLE);
        } else {
            secondaryDelete.setVisibility(View.INVISIBLE);
            addBook.setVisibility(View.INVISIBLE);
        }



    }


    public void delete() {

        secondaryDelete.setOnClickListener(v -> {

            RequestQueue queue = Volley.newRequestQueue(SecondaryActivity.this);
            StringRequest stringRequest = new StringRequest(Request.Method.DELETE, SERVICE_URI + id.toString(),
                    response -> {


                        lists.removeIf(albumList -> albumList.getId().equals(id));
                        // Internationalised - Deleting list
                        Toast.makeText(SecondaryActivity.this, getResources().getString(R.string.list_delete), Toast.LENGTH_LONG).show();

                        finish();


                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);

                        // Internationalised - Failure to delete list
                    }, error -> Toast.makeText(SecondaryActivity.this, getResources().getString(R.string.list_delete_fail), Toast.LENGTH_SHORT).show());

            queue.add(stringRequest);

        });


    }


    public void addBook() {
        addBook.setOnClickListener(v -> openDialog());
    }

    public void openDialog() {
        AddBookDialog Dialog = new AddBookDialog();
        Dialog.show(getSupportFragmentManager(), "example dialog");
        secondaryDelete.setVisibility(View.INVISIBLE);
        addBook.setVisibility(View.INVISIBLE);
    }

    @Override
    public void applyTexts(String author, String name) {   // taking in strings from dialogue class
        // Hashmap storing the variables as two strings
        secondaryDelete.setVisibility(View.VISIBLE);
        addBook.setVisibility(View.VISIBLE);

        HashMap<String, String> params = new HashMap<String, String>();
        // applying the variables
        params.put("author", author);
        params.put("name", name);

        // taking in author and name to the JSON object parameters
        RequestQueue queue = Volley.newRequestQueue(SecondaryActivity.this);
        JsonObjectRequest req = new JsonObjectRequest(Request.Method.POST, SERVICE_URI + id.toString() + "/book", new JSONObject(params),
                response -> {
                    try {
                        VolleyLog.v("Response:%n %s", response.toString(4));
                        // Internationalised - Adding book
                        Toast.makeText(SecondaryActivity.this, getResources().getString(R.string.book_added), Toast.LENGTH_LONG).show();

                        JSONArray jsonArray = new JSONArray();
                        ArrayList<Book> bookArrayList = new ArrayList<Book>();


                        Log.e("toString() error: ", response.toString());


                        if (response.optJSONArray("books") != null) {
                            jsonArray = response.optJSONArray("books");
                        }


                        if (jsonArray != null) {
                            for (int j = 0; j < jsonArray.length(); j++) {
                                JSONObject obj = jsonArray.getJSONObject(j);
                                String id = obj.getString("id");
                                String bookName = obj.getString("name");
                                String authorName = obj.getString("author");
                                bookArrayList.add(new Book(Integer.parseInt(id), authorName, bookName));
                            }
                        }

                        bookList.setBooks(bookArrayList);
                        adapter.notifyDataSetChanged();

                    } catch (JSONException e) {
                        e.printStackTrace();

                        // Internationalised - Failure to add album
                        Toast.makeText(SecondaryActivity.this, getResources().getString(R.string.book_add_fail), Toast.LENGTH_LONG).show();
                    }
                }, error -> VolleyLog.e("Error: ", error.getMessage()));

        queue.add(req);

    }

    public void openDialog3() {

        Dialog.show(getSupportFragmentManager(), "example dialog");
        secondaryDelete.setVisibility(View.INVISIBLE);
        addBook.setVisibility(View.INVISIBLE);
    }



    public String getUserId() {

        return Build.BOARD.length() % 10 + Build.BRAND.length() % 10 + Build.DEVICE.length() % 10 + Build.DISPLAY.length() % 10 + Build.HOST.length() % 10 + Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10 + Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10 + Build.TAGS.length() % 10 + Build.TYPE + Build.USER.length() % 10;
    }





}
