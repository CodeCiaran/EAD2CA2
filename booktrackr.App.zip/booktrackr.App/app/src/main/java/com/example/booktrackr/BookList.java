package com.example.booktrackr;

import java.util.ArrayList;
import java.util.List;

public class BookList {

    private Integer id;
    List<Book> books;
    private String username;
    private String name;

    public BookList(Integer id, String username, String name, ArrayList<Book> books) {
        this.id = id;
        this.books = books;
        this.username = username;
        this.name = name;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
