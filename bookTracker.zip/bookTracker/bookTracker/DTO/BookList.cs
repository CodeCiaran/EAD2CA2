﻿using System;
using System.Collections.Generic;

namespace bookTracker.DTO
{
    public class BookList
    {
        public int Id { get; set; }

        public virtual ICollection<Book> Books { get; set; }

        public DateTime Created { get; set; }

        public string Username { get; set; }

        public string Name { get; set; }

     
    }
}
