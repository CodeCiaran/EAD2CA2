﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using bookTracker.Repositories;
using bookTracker.Data;
using bookTracker.DTO;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace bookTracker.Repositories
{
    public class BookListRepository : IBookListRepository
    {
        private readonly BooktrackrContext _booktrackrContext;
        private readonly IConfiguration _configuration;

        public BookListRepository(BooktrackrContext booktrackrContext, IConfiguration configuration)
        {
            _booktrackrContext = booktrackrContext;
            _configuration = configuration;
        }

        public async Task<List<BookList>> GetLatestLists()
        {
            return await _booktrackrContext.BLists.OrderByDescending(al => al.Created).Take(25).ToListAsync();
        }

        public async Task<List<BookList>> GetMyLists(string userName)
        {
            return await _booktrackrContext.BLists.Where(al => al.Username == userName).ToListAsync();
        }

 
        public async Task<BookList> GetById(int id)
        {
            return await _booktrackrContext.BLists.Include("Books").FirstOrDefaultAsync(al => al.Id == id);
        }

        public async Task<BookList> AddToList(int id, Book book)
        {
            var list = await _booktrackrContext.BLists.Include("Books").FirstAsync(al => al.Id == id);

            if (list == null) return null;

            list.Books ??= new List<Book>();


            list.Books.Add(book);
            await _booktrackrContext.SaveChangesAsync();

            return list;
        }



        // Delete list
        public async Task<BookList> DeleteList(int id)
        {
            var list = await _booktrackrContext.BLists.Include("Books").FirstOrDefaultAsync(al => al.Id == id);

            if (list == null) return null;

            _booktrackrContext.BLists.Remove(list);
            await _booktrackrContext.SaveChangesAsync();

            return list;
        }

        public async Task<BookList> CreateBookList(string userName, string name)
        {
            var list = new BookList
            {
                Username = userName,
                Name = name,
                Books = new List<Book>(),
                Created = DateTime.Now,
            };

            await _booktrackrContext.BLists.AddAsync(list);
            await _booktrackrContext.SaveChangesAsync();


            return list;
        }

        Task<List<BookList>> IBookListRepository.GetPopularLists()
        {
            throw new NotImplementedException();
        }

        Task<BookList> IBookListRepository.DeleteFromList(int id, int aid)
        {
            throw new NotImplementedException();
        }
    }
}