﻿using System.Collections.Generic;
using System.Threading.Tasks;
using bookTracker.DTO;

namespace bookTracker.Repositories
{
    public interface IBookListRepository
    {
        Task<List<BookList>> GetLatestLists();
        Task<List<BookList>> GetPopularLists();
        Task<List<BookList>> GetMyLists(string userName);
        Task<BookList> AddToList(int id, Book album);
        Task<BookList> DeleteFromList(int id, int aid);
        Task<BookList> DeleteList(int id);
        Task<BookList> GetById(int id);
        Task<BookList> CreateBookList(string userName, string name);
        
    }
}