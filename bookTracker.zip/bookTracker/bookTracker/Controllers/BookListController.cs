﻿using System.Threading.Tasks;
using bookTracker.DTO;
using bookTracker.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace bookTracker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookListController : Controller
    {
        private readonly IBookListRepository _bookListRepository;

        public BookListController(IBookListRepository bookListRepository)
        {
            _bookListRepository = bookListRepository;
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var userList = await _bookListRepository.GetById(id);

            if (userList == null) return NotFound();

            return Ok(userList);
        }

        [HttpPost("{id}/book/")]
        public async Task<IActionResult> AddToList(int id, [FromBody] Book book)
        {
            if (book == null) return BadRequest();

            if (book.Author == string.Empty || book.Title == string.Empty)
                ModelState.AddModelError("Author/Title Name", "The author or book name is not correct.");

            if (!ModelState.IsValid) return BadRequest(ModelState);

            var userList = await _bookListRepository.AddToList(id, book);

            return Ok(userList);
        }

        [HttpPost]
        public async Task<IActionResult> CreateBookList([FromBody] BookList bookList)
        {
            if (bookList == null) return BadRequest();

            var list = await _bookListRepository.CreateBookList(bookList.Username, bookList.Name);

            if (list == null) return BadRequest();

            return Ok(list);
        }

      

     
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteList(int id)
        {
            var userList = await _bookListRepository.DeleteList(id);

            if (userList == null) return NotFound();


            return Ok(userList);
        }

        
    }
}