﻿using bookTracker.DTO;
using Microsoft.EntityFrameworkCore;

namespace bookTracker.Data
{
    public class BooktrackrContext : DbContext
    {
        public BooktrackrContext(DbContextOptions<BooktrackrContext> options)
            : base(options)
        {
        }

        public DbSet<BookList> BLists { get; set; }


        public DbSet<Book> Books { get; set; }


     
    }
}
